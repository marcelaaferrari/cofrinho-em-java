// Classe criada para o menu e submenus

package uninter;

import java.util.Scanner;

public class Menu {
	
	private Scanner scan;
	private Cofrinho cofrinho;
	
	public Menu() {
		scan = new Scanner(System.in);
		cofrinho = new Cofrinho();
	}
	
	public void mostrarMenu() {
		
		System.out.println("COFRINHO: ");
		System.out.println("1-Adicionar moeda ");
		System.out.println("2-Remover moeda");
		System.out.println("3-Listar moedas");
		System.out.println("4-Calcular total convertido para Real");
		System.out.println("0-Encerrar");
		
		String opcao = scan.next();
		
		switch(opcao) {
			case "0":
				System.out.println("Programa encerrado.");
				break;
				
			case "1":				
				subMenuAdicionarMoedas();			
				mostrarMenu();				
				break;
				
			case "2":				
				subMenuRemoverMoedas();			
				mostrarMenu();
				break;
				
			case "3":
				cofrinho.listagemMoedas();
				mostrarMenu();
				break;
				
			case "4":
				double valorTotalConvertido = cofrinho.totalConvertido();
				String valorTotalConvertidoTexto = String.format("%.2f", valorTotalConvertido);
				
				// O ponto será substituído pela vírgula, para o programa ficar visualmente melhor
				valorTotalConvertidoTexto = valorTotalConvertidoTexto.replace(".", ",");
				System.out.println("O valor total convertido para real ? " + valorTotalConvertidoTexto);
				mostrarMenu();
				break;
			
			// Se digitar uma opção que não está no menu
			default:
				System.out.println("Opcao invalida.");
				mostrarMenu();
				break;
		}
	}
	
	private void subMenuAdicionarMoedas() {
		System.out.println("Escolha a moeda:");
		System.out.println("1-Real");
		System.out.println("2-Dolar");
		System.out.println("3-Euro");				
		
		int opcaoMoeda = scan.nextInt();
		
		System.out.println("Digite o valor:");
		String valorMoedaTexto = scan.next();
		
		// Caso seja digitado vírgula, será substituída pelo ponto
		valorMoedaTexto = valorMoedaTexto.replace(",", ".");
		double valorMoeda = Double.parseDouble(valorMoedaTexto);
		
		Moeda moeda = null;
		
		if(opcaoMoeda == 1) {
			moeda = new Real(valorMoeda);					
		} else if(opcaoMoeda == 2) {
			moeda = new Dolar(valorMoeda);					
		} else if(opcaoMoeda == 3) {
			moeda = new Euro(valorMoeda);
			
		// Aqui aparecerá na tela a mensagem abaixo caso seja escolhida uma opção que não está no submenu
		} else {
			System.out.println("Moeda invalida.");
			mostrarMenu();
		}
		
		cofrinho.adicionar(moeda);
		System.out.println("Moeda adicionada.");
	}
	
	private void subMenuRemoverMoedas() {
		System.out.println("Escolha a moeda:");
		System.out.println("1-Real");
		System.out.println("2-Dolar");
		System.out.println("3-Euro");				
		
		int opcaoMoeda = scan.nextInt();
		
		System.out.println("Digite o valor:");
		String valorMoedaTexto = scan.next();
		
		valorMoedaTexto = valorMoedaTexto.replace(",", ".");
		double valorMoeda = Double.parseDouble(valorMoedaTexto);
		
		Moeda moeda = null;
		
		if(opcaoMoeda == 1) {
			moeda = new Real(valorMoeda);					
		} else if(opcaoMoeda == 2) {
			moeda = new Dolar(valorMoeda);					
		} else if(opcaoMoeda == 3) {
			moeda = new Euro(valorMoeda);		
		} else {
			System.out.println("Moeda invalida.");
			mostrarMenu();
		}
		
		if(cofrinho.remover(moeda)) {
			System.out.println("Moeda removida.");
			
		// Se for digitado um valor que não existe para a remoção, aparecerá a mensagem abaixo
		} else {
			System.out.println("Nao foi encontrada nenhuma moeda com esse valor.");
		}
	}

}

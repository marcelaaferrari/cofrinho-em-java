// Classe contendo o método principal

package uninter;

public class Principal {

	public static void main(String[] args) {
		
		Menu menu = new Menu();
		menu.mostrarMenu();
		
	}

}
